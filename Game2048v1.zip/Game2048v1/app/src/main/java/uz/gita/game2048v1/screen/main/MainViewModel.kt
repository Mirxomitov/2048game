package uz.gita.game2048v1.screen.main

class MainViewModel {
}