package uz.gita.game2048v1.screen.info

import androidx.fragment.app.Fragment
import uz.gita.game2048v1.R

class InfoScreen : Fragment(R.layout.screen_info) {
}