package uz.gita.game2048v1.data.model

enum class SideEnum {
    RIGHT, LEFT, UP, DOWN
}