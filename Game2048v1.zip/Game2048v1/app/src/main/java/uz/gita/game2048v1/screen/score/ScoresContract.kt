package uz.gita.game2048v1.screen.score

interface ScoresContract {
    interface View
    interface ViewModel {
        fun showScores()
    }
}